def add(a, b):
    return a + b

if __name__ == "__main__":
    print("sum:", add(2, 3))