import test from 'node:test'
import assert from 'node:assert/strict'
import http from 'node:http'

test('server responds /health', async (t) => {
  const server = (await import('../src/server.js')).default
})