import express from 'express'
const app = express()

app.get('/health', (_req, res) => res.json({status: 'ok'}))
app.get('/api/projects', (_req, res) => {
  res.json([
    { name: 'App Chantiers (.NET/C#)', repo: 'app-chantiers-dotnet' },
    { name: 'Refonte Full Stack RNF', repo: 'rnf-refonte-angular-flask' },
    { name: 'Algo C/C++ RepRap', repo: 'firmware-reprap-algo' },
    { name: 'E‑commerce Mumade', repo: 'mumade-ecommerce' },
    { name: 'DevSecOps – Juice Shop', repo: 'juice-shop-devsecops' },
    { name: 'Deep Learning – Trajectoire', repo: 'trajectory-dl' },
    { name: 'Frais de carburant', repo: 'carburant-calc' }
  ])
})

const port = process.env.PORT || 8000
app.listen(port, () => console.log(`[devopshub] API lancée sur : http://localhost:${port}`))