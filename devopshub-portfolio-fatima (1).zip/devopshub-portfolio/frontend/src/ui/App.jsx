import React from 'react'

const Section = ({ title, children }) => (
  <section style={{marginBottom: '24px'}}>
    <h2 style={{marginBottom: 8, color: '#0b3d91'}}>{title}</h2>
    <div>{children}</div>
  </section>
)

export default function App() {
  const projects = [
    { name: 'App Chantiers (.NET/C#)', link: 'https://github.com/<VOTRE_GITHUB>/app-chantiers-dotnet', stack: 'C#, .NET, SQL, Docker, CI/CD' },
    { name: 'Refonte Full Stack RNF', link: 'https://github.com/<VOTRE_GITHUB>/rnf-refonte-angular-flask', stack: 'Angular 15, Flask, PostgreSQL, Linux' },
    { name: 'Algo C/C++ RepRap', link: 'https://github.com/<VOTRE_GITHUB>/firmware-reprap-algo', stack: 'C/C++, Firmware, RepRap' },
    { name: 'E‑commerce Mumade', link: 'https://github.com/<VOTRE_GITHUB>/mumade-ecommerce', stack: 'HTML, CSS, AngularJS, Figma' },
    { name: 'DevSecOps – Juice Shop', link: 'https://github.com/<VOTRE_GITHUB>/juice-shop-devsecops', stack: 'GitLab CI/CD, SonarQube, Trivy, Grafana' },
    { name: 'Deep Learning – Trajectoire', link: 'https://github.com/<VOTRE_GITHUB>/trajectory-dl', stack: 'PyTorch, TensorFlow' },
    { name: 'Frais de carburant', link: 'https://github.com/<VOTRE_GITHUB>/carburant-calc', stack: 'VueJS, Spring Boot, MySQL' },
  ]

  return (
    <main style={{maxWidth: 920, margin: '40px auto', fontFamily: 'Inter, system-ui, Arial', lineHeight: 1.5, padding: '0 16px'}}>
      <header style={{marginBottom: 24, borderBottom: '1px solid #e5e7eb', paddingBottom: 12}}>
        <h1 style={{margin: 0, fontSize: 28}}>Fatima Seggaoui</h1>
        <p style={{margin: '6px 0 0', color: '#334155'}}>Développeuse Full Stack & DevSecOps</p>
        <p style={{margin: '6px 0 0'}}>✉ fatimaseggaoui0409@gmail.com · ☎ +33 7 53 55 22 74 · France</p>
      </header>

      <Section title="À propos">
        <p>Étudiante en Master 2 – Architecture des Systèmes d’Information. Alternance 1 an (2025–2026), rythme 1/3. Passionnée par le développement, l’automatisation CI/CD, et la sécurité applicative.</p>
      </Section>

      <Section title="Projets en avant">
        <ul>
          {projects.map(p => (
            <li key={p.name} style={{marginBottom: 8}}>
              <strong>{p.name}</strong> — {p.stack} — <a href={p.link} target="_blank">code</a>
            </li>
          ))}
        </ul>
      </Section>

      <Section title="Stack">
        <p><strong>Dév :</strong> React, Node, Python, Java, C# · <strong>DB :</strong> PostgreSQL, MySQL · <strong>DevOps :</strong> Docker, GitHub Actions, Kubernetes (base)</p>
      </Section>
    </main>
  )
}