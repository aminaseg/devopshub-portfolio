## Profil rapide

- **Nom** : Fatima Seggaoui  
- **Titre** : Développeuse Full Stack & DevSecOps  
- **Contact** : fatimaseggaoui0409@gmail.com · +33 7 53 55 22 74 · France  
- **Alternance** : 1 an (2025–2026), rythme 1/3  

## Liens à compléter
- Remplacez `<VOTRE_GITHUB>` dans `frontend/src/ui/App.jsx` par votre nom d'utilisateur GitHub.
- Ajoutez les URLs de vos dépôts réels pour chaque projet.